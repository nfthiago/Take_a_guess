#Programa feito por Thiago França - 20/03/2022
#Biblioteca que será usada pelo programa para criar um número aleatório
import random

#Variáveis e inicializações (atribuições iniciais)
#Variável para guardar o número aleatório que será secreto ao utilizador e que ele tentará adivinhar
secretNum = int(random.randint(1, 100))
#Variável que guarda o número de tentativas para acertar o número
count = 1
#Variável booleana que indica se o número secreto foi corretamente sugerido ou não
wrong = False

#Lidando com as exceções quando o utilizador insere algo que não seja um número
try:
    #Variável que guardará os valores experimentados do utilizador (input)
    guess = int(input("\n\nExiste um número secreto de 1 a 100. Você tem 5 tentativas para adivinhá-lo. \n "
                    "Para jogar, basta escrever um número e dar enter! \n"))
    #Se não for um número, levantar o erro de valor
    if type(guess) is not int:
        raise ValueError()
#Lindando com possível erro de valor
except ValueError:
    # mensagem de erro e pedido de input de nova entrada do utilizador
    guess = input("\n**** Erro! O valor deverá ser um número de 1 a 100 ****\n")

#Ciclo while que faz com que o programa volte a rodar até que o número seja adivinhado ou até no máximo de 5 tentativas
while count <= 5:
    #Condicional que testa se o utilizador acertou o número, se ele chutou baixo demais ou alto demais
    #Primeira hipótese: se o número chutado foi muito baixo
    if int(guess) < secretNum:
        count = count + 1
        wrong = True
        guess = input("Tente novamente. Agora com um número mais alto! ")
    #Segunda hipótese: se o número chutado foi muito alto
    elif int(guess) > secretNum:
        count = count + 1
        wrong = True
        guess = input("Você chutou muito alto. Mire mais baixo! ")
    #Terceira e última hipótese: se o número chutado for igual ao número secreto
    elif int(guess) == secretNum:
        print("Parabéns!! Você conseguiu descobrir o número secreto em " + str(count) + " tentativas!")
        count = 6
        wrong = False

#Condicional que devolve uma mensagem ao utilizador quando as 5 tentativas acabam e o número secreto não tenha sido adivinhado
if wrong:
    print("Acabaram as tentativas. Você não descobriu qual era o número secreto! O número secreto era", secretNum, "!")
